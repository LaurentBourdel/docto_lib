
require 'faker'

Location.destroy_all
Doctor.destroy_all
Patient.destroy_all
Appointment.destroy_all

10.times do

	# seed for locations
	Location.create!(
		city_name: Faker::Address.city
		)
	# seed for doctors
  Doctor.create!(
  	first_name: Faker::Name.first_name, 
  	last_name: Faker::Name.last_name, 
  	zip_code: Faker::Address.postcode, 
  	city_name: Faker::Address.city, 
  	location_id: Location.all.sample.id
  	)
  # seed for patients
  Patient.create!(
  	first_name: Faker::Name.first_name, 
  	last_name: Faker::Name.last_name, 
  	city_name: Faker::Address.city, 
  	location_id: Location.all.sample.id
  	)
  # seed for appointments
  Appointment.create!(
  	doctor_id: Doctor.all.sample.id, 
  	patient_id: Patient.all.sample.id, 
  	date: Faker::Date.in_date_period, 
  	location_id: Location.all.sample.id
  	) 

  # seed for specialties
  Specialty.create!(
    name: Faker::Job.field, 
    ) 

  # seed for specialties
  Competence.create!(
    doctor_id: Doctor.all.sample.id, 
    specialty_id: Specialty.all.sample.id, 
    ) 

end