class Competence < ApplicationRecord
	belongs_to :doctor, required: false
  belongs_to :specialty, required: false
end
