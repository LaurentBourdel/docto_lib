class Specialty < ApplicationRecord
	has_many :competencies, dependent: :destroy 
  has_many :doctors, through: :competencies
end
