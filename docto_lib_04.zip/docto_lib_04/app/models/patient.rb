class Patient < ApplicationRecord
  belongs_to :location, required: false
  has_many :appointments, dependent: :destroy 
  has_many :doctors, through: :appointments
end
